#ifndef ARTNET_H
#define ARTNET_H

void ethernetSetup();
void serialSetup();
void packetRead();
void artnetParse();
void packetDump();
#endif
